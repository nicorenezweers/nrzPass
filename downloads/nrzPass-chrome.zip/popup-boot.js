import init, * as bindings from '/nrzpass-web-8f5532ec16359798.js';
const wasm = await init({ module_or_path: '/nrzpass-web-69675b3ad0513ca3_bg.wasm' });


window.wasmBindings = bindings;


dispatchEvent(new CustomEvent("TrunkApplicationStarted", {detail: {wasm}}));
