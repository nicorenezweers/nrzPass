import init, * as bindings from '/nrzpass-web-856f729f40eebbc5.js';
const wasm = await init({ module_or_path: '/nrzpass-web-414a184dbeea18d_bg.wasm' });


window.wasmBindings = bindings;


dispatchEvent(new CustomEvent("TrunkApplicationStarted", {detail: {wasm}}));
